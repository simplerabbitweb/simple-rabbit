<?php
/**
 * Instagram strip, contact block, colophon.
 *
 * @package goodwin
 */

$gw_instagram = gw_contact( 'instagram' );
?>

	<?php if ( $gw_instagram ) : ?>
		<section class="ig wrap">
			<div class="ig__head reveal">
				<div>
					<p class="label">Follow the work</p>
					<h2>@<?php echo esc_html( $gw_instagram ); ?></h2>
				</div>
				<a class="btn" href="https://www.instagram.com/<?php echo esc_attr( $gw_instagram ); ?>/" target="_blank" rel="noopener">Follow on Instagram</a>
			</div>

			<?php
			if ( shortcode_exists( 'instagram-feed' ) ) {
				// Smash Balloon, styled by the theme's .ig__strip rules.
				echo do_shortcode( '[instagram-feed num=6 cols=6 showheader=false showbutton=false showfollow=false]' );
			} else {
				// Fallback until the feed plugin is connected: recent project photos.
				$gw_recent = new WP_Query(
					array(
						'post_type'      => 'project',
						'posts_per_page' => 6,
						'meta_key'       => '_thumbnail_id',
					)
				);

				if ( $gw_recent->have_posts() ) :
					?>
					<div class="ig__strip">
						<?php
						while ( $gw_recent->have_posts() ) :
							$gw_recent->the_post();
							?>
							<a href="#work">
								<?php the_post_thumbnail( 'gw-square', array( 'loading' => 'lazy' ) ); ?>
							</a>
							<?php
						endwhile;
						?>
					</div>
					<?php
				endif;
				wp_reset_postdata();
			}
			?>
		</section>
	<?php endif; ?>

	<section class="contact" id="contact">
		<div class="wrap contact__grid">
			<div>
				<p class="label">Get in touch</p>
				<h2>Tell me about the <em>room</em></h2>
				<p class="lede" style="color:rgba(237,234,225,.78)">
					Send through the space, the finish you have in mind and a photo if you have one. Quotes are free.
				</p>

				<ul class="details">
					<li>
						<span>Phone</span>
						<span><a href="tel:<?php echo esc_attr( gw_contact( 'phone_link' ) ); ?>"><?php echo esc_html( gw_contact( 'phone' ) ); ?></a></span>
					</li>
					<li>
						<span>Email</span>
						<span><a href="mailto:<?php echo esc_attr( gw_contact( 'email' ) ); ?>"><?php echo esc_html( gw_contact( 'email' ) ); ?></a></span>
					</li>
					<li>
						<span>Studio</span>
						<span><?php echo esc_html( gw_contact( 'address' ) ); ?></span>
					</li>
					<?php if ( $gw_instagram ) : ?>
						<li>
							<span>Instagram</span>
							<span><a href="https://www.instagram.com/<?php echo esc_attr( $gw_instagram ); ?>/" target="_blank" rel="noopener">@<?php echo esc_html( $gw_instagram ); ?></a></span>
						</li>
					<?php endif; ?>
					<?php if ( gw_contact( 'licence' ) ) : ?>
						<li>
							<span>Licence</span>
							<span><?php echo esc_html( gw_contact( 'licence' ) ); ?></span>
						</li>
					<?php endif; ?>
				</ul>
			</div>

			<div class="form">
				<?php
				// Drop the form plugin's shortcode into a widget area or edit this line.
				if ( shortcode_exists( 'contact-form-7' ) && get_option( 'gw_form_shortcode' ) ) {
					echo do_shortcode( get_option( 'gw_form_shortcode' ) );
				} elseif ( is_active_sidebar( 'gw-contact-form' ) ) {
					dynamic_sidebar( 'gw-contact-form' );
				} else {
					?>
					<p class="label">Add the enquiry form here — paste the form shortcode into the Contact form widget area (Appearance → Widgets).</p>
					<?php
				}
				?>
			</div>
		</div>

		<div class="wrap colophon">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></span>
			<span>Decorative wall finishes · Newcastle · Port Stephens · Central Coast</span>
			<?php // Only links out if a privacy policy page is actually set. ?>
			<?php if ( get_privacy_policy_url() ) : ?>
				<span><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>">Privacy</a></span>
			<?php else : ?>
				<span>Licence <?php echo esc_html( gw_contact( 'licence' ) ? gw_contact( 'licence' ) : '—' ); ?></span>
			<?php endif; ?>
		</div>
	</section>
</main>

<?php wp_footer(); ?>
</body>
</html>
